//
//  MenuViewController.swift
//  Pizza Delivery (UIKit)
//
//  Created by Justin Chester on 2020-01-14.
//  Copyright © 2020 Justin Chester. All rights reserved.
//

import UIKit

class MenuViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let greenColorCode = 0x69834d
        //let beigeColorCode = 0xf2e9de
        let greenColor = UIColor(rgb: greenColorCode)
        self.view.backgroundColor = greenColor
        
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
