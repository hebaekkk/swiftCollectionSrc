//
//  RatingView.swift
//  Bookworm
//
//  Created by Florian Hainka on 07.01.21.
//

import SwiftUI

struct RatingView: View {
	@Binding var rating: Int16
	
    var body: some View {
		HStack {
			ForEach(1 ..< 6) { index in
				Image(systemName: rating < index ? "star" : "star.fill")
					.font(.system(size: 24))
					.onTapGesture {
						self.rating = Int16(index)
					}
			}
		}
    }
}

struct RatingView_Previews: PreviewProvider {
    static var previews: some View {
		RatingView(rating: .constant(3))
    }
}
