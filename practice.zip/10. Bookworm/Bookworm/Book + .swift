//
//  Date + FormattedDate.swift
//  Bookworm
//
//  Created by Florian Hainka on 07.01.21.
//

import Foundation

extension Book {
	var formattedDateFinished: String {
		if let date = dateFinished {
			let formatter = DateFormatter()
			formatter.dateFormat = "d.MM.yyyy"
			return formatter.string(from: date)
		}
		return "N/A"
	}
}
