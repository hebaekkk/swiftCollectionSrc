//
//  MainViewController.swift
//  ExpyTableView
//
//  Created by Okhan on 16/06/2017.
//  Copyright © 2017 CocoaPods. All rights reserved.
//

import UIKit

class MainViewController: UIViewController {
	override func viewDidLoad() {
		super.viewDidLoad()
		navigationItem.title = "Expy Examples"
	}
}
