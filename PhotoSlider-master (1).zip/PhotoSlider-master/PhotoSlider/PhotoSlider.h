//
//  PhotoSlider.h
//  PhotoSlider
//
//  Created by nakajijapan on 2015/12/28.
//  Copyright © 2015 nakajijapan. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for PhotoSlider.
FOUNDATION_EXPORT double PhotoSliderVersionNumber;

//! Project version string for PhotoSlider.
FOUNDATION_EXPORT const unsigned char PhotoSliderVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <PhotoSlider/PublicHeader.h>


