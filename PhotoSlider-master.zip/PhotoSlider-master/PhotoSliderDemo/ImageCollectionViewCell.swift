//
//  ImageCollectionViewCell.swift
//  PhotoSliderDemo
//
//  Created by nakajijapan on 2015/09/24.
//  Copyright © 2015 net.nakajijapan. All rights reserved.
//

import UIKit

class ImageCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var imageView: UIImageView!
    
}
