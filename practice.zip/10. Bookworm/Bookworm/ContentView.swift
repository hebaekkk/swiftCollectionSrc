//
//  ContentView.swift
//  Bookworm
//
//  Created by Florian Hainka on 07.01.21.
//

import SwiftUI
import CoreData

struct ContentView: View {
	
	@Environment(\.managedObjectContext) var viewContext: NSManagedObjectContext
	
	@FetchRequest(entity: Book.entity(), sortDescriptors:
					[NSSortDescriptor(key: "dateFinished", ascending: true)])
	var books: FetchedResults<Book>
	
	@State var showAddBookView = false

    var body: some View {
		NavigationView {
			List {
				ForEach(books, id: \.id) { book in
					NavigationLink(destination: DetailsView(book: book)) {
						VStack(alignment: .leading) {
							Text(book.title ?? "N/A")
								.bold()
								.font(.headline)
							Text(book.author ?? "N/A")
						}
					}
				}
				.onDelete(perform: { indexSet in
					self.delete(at: indexSet)
				})
			}
			.navigationTitle("Bookworm")
			.navigationBarItems(trailing:
				Button(action: {
					showAddBookView = true
				}, label: {
//					Text("Button")
					Image(systemName: "plus")
						.font(.system(size: 24))
				})
			)
			.sheet(isPresented: $showAddBookView, content: { AddBookView() })
		}
    }

	
	func delete(at indexSet: IndexSet) {
		for index in indexSet {
			let bookToRemove = books[index]
			viewContext.delete(bookToRemove)
		}
		
		try? viewContext.save()
	}
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
