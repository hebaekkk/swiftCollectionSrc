//
//  DetailsView.swift
//  Bookworm
//
//  Created by Florian Hainka on 07.01.21.
//

import CoreData
import SwiftUI

struct DetailsView: View {
	@Environment(\.managedObjectContext) private var viewContext: NSManagedObjectContext
	@Environment(\.presentationMode) private var presentationMode
	
	let book: Book
	
    var body: some View {
		VStack(spacing: 0) {
			GeometryReader { reader in
				ZStack {
					Image(book.genre ?? "Other")
						.resizable()
						.scaledToFill()
					
					let width: CGFloat = 100
					let height: CGFloat = 50
					Text(book.genre ?? "N/A")
						.bold()
						.font(.headline)
						.foregroundColor(.white)
						.frame(width: width, height: height)
						.background(Color.black)
						.position(x: reader.size.width - width / 2,
								  y: reader.size.height - height / 2)
				}
			}
			.frame(height: 200)
			.clipped()
			
			List {
				ListRow(title: "Title", label: Text(book.title ?? "N/A"))
				ListRow(title: "Author", label: Text(book.author ?? "N/A"))
				ListRow(title: "Date Finished", label: Text(book.formattedDateFinished))
				ListRow(title: "Rating", label: RatingView(rating: .constant(book.rating)))
				ListRow(title: "Review", label: Text(book.review ?? ""), alignment: .top)
			}
		}
		.navigationTitle(book.title ?? "N/A")
		.navigationBarItems(trailing:
			Button(action: {
				viewContext.delete(book)
				try? viewContext.save()
				presentationMode.wrappedValue.dismiss()
			}, label: {
				Image(systemName: "trash")
					.font(.system(size: 22))
			})
		)
    }
}



struct ListRow<content: View>: View {
	let title: String
//	let details: String
	let label: content
	var alignment: VerticalAlignment = .center
	
	
	var body: some View {
		HStack(alignment: alignment) {
			Text(title + ":")
				.bold()
			label
		}
	}
}

struct DetailsView_Previews: PreviewProvider {
	static let viewContext = PersistenceController.shared.viewContext
    static var previews: some View {
		let newBook = Book(context: viewContext)
		newBook.title = "Es 2"
		newBook.dateFinished = Date()
		newBook.genre = "Horror"
		newBook.rating = 3
		newBook.id = UUID()
		newBook.review = "Best book I have ever read. I know nothing about it but it is still a classic and the film was amazing."
		newBook.author = "Steven King"
		return NavigationView {
			DetailsView(book: newBook)
		}
    }
}
