//
//  AddBookView.swift
//  Bookworm
//
//  Created by Florian Hainka on 07.01.21.
//

import SwiftUI
import CoreData

struct AddBookView: View {
	@Environment(\.presentationMode) var presentationMode
	@Environment(\.managedObjectContext) var viewContext: NSManagedObjectContext
	
	static private let genres = ["Fantasy", "Horror", "Classic", "Romance", "Other"]

	
	@State var title = ""
	@State var genre: String = AddBookView.genres[0]
	@State var rating: Int16 = 3
	@State var review = ""
	@State var author = ""
	
    var body: some View {
		NavigationView {
			Form {
				TextField("Title", text: $title)
				TextField("Author", text: $author)
				
				Picker("Genre:", selection: $genre) {
					ForEach(AddBookView.genres, id: \.self) { genre in
						Text(genre)
					}
				}
				
				Section(header: Text("Rating:")) {
					RatingView(rating: $rating)
						.padding(.vertical)
				}
				
				Section(header: Text("Review:")) {
					TextEditor(text: $review)
				}
				
				Section {
					Button(action: {
						self.save()
						presentationMode.wrappedValue.dismiss()
					}, label: {
						Text("Save")
					})
					.disabled(isInvalid())
				}
			}
			.navigationTitle("Add Book")
		}
    }
	
	func save() {
		let newBook = Book(context: viewContext)
		newBook.id = UUID()
		newBook.title = title
		newBook.genre = genre
		newBook.dateFinished = Date()
		newBook.rating = rating
		newBook.review = review
		newBook.author = author

		try? viewContext.save()
	}
	
	func isInvalid() -> Bool {
		if (title.isEmpty) { return true }
		if (author.isEmpty) { return true }
		return false
	}
}

struct AddBookView_Previews: PreviewProvider {
    static var previews: some View {
		AddBookView()
    }
}
